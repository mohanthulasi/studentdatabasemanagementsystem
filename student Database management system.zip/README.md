# collage-website
This is a responsive website for collage purpose. firstly we would have to login for go to next page in this website. In this website Admin can handle the data of the students and teachers as well as admin can manage other data also.
